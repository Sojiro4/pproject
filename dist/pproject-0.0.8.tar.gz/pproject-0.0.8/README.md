# About the pproject
Predicted price change for iPhone in XX years

### how to install pproject

$ pip install pproject

### required Libraries

pandas<br>
numpy<br>
scikit-learn<br>
matplotlib<br>
datetime

### how to run pproject
< ~ .py><br>
import pproject<br>
pproject.price_fluctuation_now()</br></br>
$python ~.py
![Figure1](https://raw.githubusercontent.com/Sojiro4/pproject/main/img/Figure_1.png)

classification0 : iPhone SE series</br>
classification1 : Regular iPhone series</br>
classification2,3,4 : Other series (Pro, Plus, etc.)</br></br>


< ~ .py></br>
import pproject</br>
pproject.Predicted_price_change_in_XX_years(100)</br></br>
$python ~.py
![Figure2](https://raw.githubusercontent.com/Sojiro4/pproject/main/img/Figure_2.png)

Prediction by regular series

