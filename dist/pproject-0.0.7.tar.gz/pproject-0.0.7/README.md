# About the pproject
Predicted price change for iphone in XX years

### how to install pproject

$ pip install pproject

### required Libraries

pandas<br>
numpy<br>
scikit-learn<br>
matplotlib<br>
datetime

### how to run pproject
< ~ .py><br>
import pproject<br>
pproject.price_fluctuation_now()</br></br>
$python ~.py
![Figure1](img/Figure_1.png)


< ~ .py></br>
import pproject
pproject.Predicted_price_change_in_XX_years(100)</br></br>
$python ~.py
![Figure2](img/Figure_2.png)

